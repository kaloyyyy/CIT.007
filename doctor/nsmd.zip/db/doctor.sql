insert into doc.doctor (d_id, given_name, sur_name)
values  (1, 'Juan', 'Dela Cruz'),
        (2, 'Quack', 'Duck'),
        (3, 'Jeff', 'Bezos');