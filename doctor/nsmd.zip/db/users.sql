insert into doc.users (userID, username, password, created_at, userType)
values  (1, 'doc', '$2y$10$.4KXlJjLmNBSkew71qusQ./Uj6twUDUq2senKH79HemWxWbGM5/.S', '2022-11-19 20:27:21', 1),
        (2, 'doc2', '$2y$10$.4KXlJjLmNBSkew71qusQ./Uj6twUDUq2senKH79HemWxWbGM5/.S', '2022-11-19 20:27:21', 1),
        (3, 'doc3', '$2y$10$.4KXlJjLmNBSkew71qusQ./Uj6twUDUq2senKH79HemWxWbGM5/.S', '2022-11-19 20:27:46', 1),
        (4, 'patient', '$2y$10$.4KXlJjLmNBSkew71qusQ./Uj6twUDUq2senKH79HemWxWbGM5/.S', '2022-11-19 20:36:21', 0),
        (5, 'admin', '$2y$10$.4KXlJjLmNBSkew71qusQ./Uj6twUDUq2senKH79HemWxWbGM5/.S', '2022-11-19 23:42:17', 2);