<div class="background h-100 w-100" style="position: fixed; bottom: 0px; width: 100vw; z-index: -1">
    <img class="bgimg w-100 h-100" alt="" src="/background.png" style="object-fit: cover">

</div>