<?php

require_once('config/config.php');
require_once('config/meta.php');
$id = $_SESSION['id'];
?>

<html lang="en">
<head>
    <title>SODA | Appointments</title>
</head>
<body>
<div class='d-flex flex-column justify-content-center align-items-center'>
    <h4>click the appointment you want to edit</h4>
    <div id="viewApp">

    </div>

    <input class="d-none" value="" id="app_id">
</body>
<script>
    $('#viewApp').load('/soda/src/updateApp/loadApp.php')
    function cancelApp(id) {
    $('#app_id').load('/soda/src/updateApp/cancelApp.php',{ap_id: id});
    }

    function editNow(id) {
        $('.wrapper').addClass('d-none')
        $('.appList').addClass('editApp').removeClass('activeEdit')
        $('#' + id).removeClass('editApp').addClass('activeEdit')

        $('#hide' + id).removeClass('d-none ')
    }
</script>
</html>
