<?php

if ($userType = 2 || 0) {
    echo 'user or admin';
}