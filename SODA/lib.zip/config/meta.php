<meta charset="UTF-8">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">
<script src="/soda/lib/fontawesome-free-6.2.0-web/js/all.js" crossorigin="anonymous"></script>


<link rel="stylesheet" href="/soda/lib/bootstrap.css"
    <?php echo '?v=' . time(); ?> type="text/css" media="screen, projection"/>

<script src="/soda/lib/jquery-3.6.1.js"></script>
<script src="/soda/lib/bootstrap.js"></script>
<link rel="stylesheet" href="/soda/lib/style.css"
    <?php echo '?v=' . time(); ?> type="text/css" media="screen, projection"/>